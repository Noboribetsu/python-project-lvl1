"""Scritp with a game - brain-calc."""

from brain_games.games.games import brain_calc


def main():
    brain_calc()


if __name__ == '__main__':
    main()
