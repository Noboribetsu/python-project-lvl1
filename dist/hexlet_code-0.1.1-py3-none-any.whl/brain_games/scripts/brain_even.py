"""Scritp with a game - brain-even."""

from brain_games.games import brain_even


def main():  # noqa: D103
    brain_even()


if __name__ == '__main__':
    main()
