"""Scritp with a game - brain-even."""

from brain_games.games.games import brain_even


def main():
    brain_even()


if __name__ == '__main__':
    main()
